function outc = addcomp2(z1,z2)
outc=z1+z2;