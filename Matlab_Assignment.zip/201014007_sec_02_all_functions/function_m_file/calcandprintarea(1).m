radius = readradius;
area = calcarea(radius);
printarea(radius, area)