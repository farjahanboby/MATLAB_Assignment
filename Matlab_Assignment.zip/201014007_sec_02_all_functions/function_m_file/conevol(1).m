function outarg = conevol(radius, height)
% Calculates the volume of a cone
outarg = (pi/3) * radius *radius * height;