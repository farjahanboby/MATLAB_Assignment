radius = input('Please enter the redius: ');
if radius <=0
    fprintf('sorry; %.2f is not a valid radius\n', radius)
else
    area = calcarea(radius);
    fprintf('For a circle with a radius of %.2f,', radius)
    fprintf('the area is %.2f\n', area)
end