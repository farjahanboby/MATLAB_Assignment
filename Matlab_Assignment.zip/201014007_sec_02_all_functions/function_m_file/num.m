num = -4;
if num < 0
    num = abs(num)
end
num = 5;
if num < 0
    num = abs(num)
end