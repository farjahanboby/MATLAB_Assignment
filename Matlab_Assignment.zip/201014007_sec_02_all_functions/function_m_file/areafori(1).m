function area = areafori(varargin)
n = nargin;
radius = varargin{1};
if n==2
    unit = varargin{2};
    if unit=='i'
        radius = radius * 12;
    end
end
area = pi * radius ^2;