function outarg = myvecsum(vec)
outarg = 0;
for i = 1:length(vec)
    outarg = outarg + vec(i);
end