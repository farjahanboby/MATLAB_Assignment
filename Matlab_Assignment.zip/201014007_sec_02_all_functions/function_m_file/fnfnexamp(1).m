function fnfnexamp(funh)
x = 1:.25:6;
y = funh(x);
plot(x,y,'ko')