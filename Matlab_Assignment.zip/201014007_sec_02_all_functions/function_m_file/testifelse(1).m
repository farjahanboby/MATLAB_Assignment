function testifelse(x)
if 3 < x < 6
    disp('In middle of range')
else
    disp('Out of range')
end