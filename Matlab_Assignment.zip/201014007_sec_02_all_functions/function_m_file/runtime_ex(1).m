vec = 3:5;
for i = 1:4
    disp(vec(i))
end