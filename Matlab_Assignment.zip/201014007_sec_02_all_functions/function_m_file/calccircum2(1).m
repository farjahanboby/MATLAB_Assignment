function circle_circum = calccircum2(radius)
circle_circum = 2 * pi * radius;