function outc =addcomp(z1,z2) % we have to pass argument in the command window || addcomp(3+4i,2-3j)
realpart =real(z1)+real(z2); % adding real numbers separately
imagpart=imag(z1)+imag(z2);% adding imaginary separately
outc=realpart +imagpart*i;