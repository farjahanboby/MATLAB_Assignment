function printrand()
fprintf('The random # i %.2f\n', rand)