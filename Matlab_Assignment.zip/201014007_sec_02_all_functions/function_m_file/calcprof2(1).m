function profit = calcprof2(oneprice, onecost)
profit = oneprice - onecost;