function outmat = multtable (rows, columns)
outmat = zeros(rows, columns);
for i = 1:rows
    for j = 1: columns
        outmat (i, j) = i *j;
    end
end
