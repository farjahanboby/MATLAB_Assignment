[length, width] = readlenwid;
printrectarea(length, width)