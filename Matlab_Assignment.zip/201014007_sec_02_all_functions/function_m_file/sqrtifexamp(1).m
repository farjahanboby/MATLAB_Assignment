num = input('Please enter a number: ');
if num < 0
    num = abs(num);
end
fprintf('The sqrt of %.1f is %.1f\n', num, sqrt(num))