function area = areafori2(radius, varargin)
n = nargin;
if n==2
    unit = varargin{1};
    if unit=='i'
        radius = radius * 12;
    end
end
area = pi * radius ^2;