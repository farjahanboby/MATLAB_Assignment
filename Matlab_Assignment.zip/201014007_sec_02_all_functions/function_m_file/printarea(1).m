function printarea(rad, area)
fprintf('For a circle with a radius of %.2f inches.\n', rad)
fprintf('the area is %.2f inches squared.\n', area)