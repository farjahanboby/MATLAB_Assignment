function radius = readradius
disp('When prompted, please enter the radius in inches.')
radius = input('Enter the radius: ');