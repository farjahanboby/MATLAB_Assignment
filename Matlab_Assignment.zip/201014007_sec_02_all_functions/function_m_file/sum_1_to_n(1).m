function runsum = sum_1_to_n(n)
runsum = 0;
for i = 1:n
    runsum = runsum +i;
end