load experd.dat
i = 1;
while experd(i) = -99
    newvec(i) = experd(i);
    i = i+1;
end
plot(newvec, 'ko')