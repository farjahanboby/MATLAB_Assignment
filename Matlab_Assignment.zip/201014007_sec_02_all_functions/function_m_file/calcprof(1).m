function profit = calcprof(packstruct)
profit = packstruct.price - packstruct.cost;