[x,y]=meshgrid(-128:217,-128:127);
z=sqrt(x.^2+y.^2);
c=(z<15);
cf=fft2shift(fft2(z));
fftshow(cf,'log')