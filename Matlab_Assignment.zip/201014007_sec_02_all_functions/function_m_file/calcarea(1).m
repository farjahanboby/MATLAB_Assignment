function area = calcarea(rad)
% This function calculates the area of a circle
area = pi * rad * rad;