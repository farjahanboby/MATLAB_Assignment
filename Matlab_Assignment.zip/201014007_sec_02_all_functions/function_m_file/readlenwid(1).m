function [l,w] = readlenwid
l = input('Please enter the length: ');
w = input('Please enter the width: ');