function outvec = myveccumsumii(vec)
outvec = zeros(size(vec));
runsum = 0;
for i=1:length(vec)
    runsum = runsum + vec(i);
    outvec(i) = runsum;
end