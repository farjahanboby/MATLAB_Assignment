function outarg = myvecprod(vec)
outarg = 1;
for i = 1:length(vec)
    outarg = outarg * vec(i);
end