function y = calcy(x)
if x< -1
    y = 1;
elseif x>= -1 && x<=2
        y = x^2;
    else
        y = 4;
 end