function outcost = cylcost(radius, height, cost)
%calculates the cost of constructing a closed cylinder
% radius and height are in inches

surf_area = 2 * pi * radius * height + 2 * pi * radius ^ 2;
surf_areasf = ceil(surf_area/144);
outcost = surf_areasf * cost;