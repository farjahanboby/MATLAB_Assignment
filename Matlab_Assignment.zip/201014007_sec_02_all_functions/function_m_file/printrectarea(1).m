function printrectarea(len, wid)
area = calcrectarea(len, wid);
fprintf('For a rectangle wih a length of %.2f\n', len)
fprintf('and a width of %.2f the area is %.2f\n', wid, area);
function area = calcrectarea(len, wid)
area = len * wid;