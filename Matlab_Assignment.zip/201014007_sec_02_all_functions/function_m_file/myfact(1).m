function runprod = myfact(n)
runprod = 1;
for i = 1:n
    runprod = runprod * i;
end