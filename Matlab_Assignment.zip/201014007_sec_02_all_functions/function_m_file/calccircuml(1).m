function calccircuml(radius)
disp(2 * pi * radius)