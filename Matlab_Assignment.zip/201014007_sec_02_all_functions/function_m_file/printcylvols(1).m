function printcylvols(cyls)
for i = 1:length(cyls)
    vol = cylvol(cyls(i). dimensions);
    fprintf('Cylinder %c has a volume of %.1f\n', cyls(i).code, vol);
end
function cvol = cylvol(dims)
cvol = pi * dims.rad ^2 * dims.height;