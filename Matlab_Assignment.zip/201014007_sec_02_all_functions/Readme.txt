 3:42 PM 2/5/2022

<------------------------------------Folder Information------------------------------>

In this assignment I have saved 

1)2 different live script files in "All_live_script" folder
2)All the PDF of live script file in "All_pdf" folder
3)All the script and images for function in "function_m_file" folder


<-------------------------------------How to execute---------------------------------->

1) After saving all these images, m files, xls file and mlx file in the matlab location we have to run live script.
  
            a) First of all have to run "20101400_lecture_1_to_4.mlx" file
            b) After some time  in the command window user have to push input for prompt
            c) when prompted "Never give up....." , we have to push int value
            d)The outcome for 1) in the "20101400_lecture_1_to_4.pdf" file

2) Then we have to run "201014007_lecture_9.mlx" live script file.

                  The outcome for 2) in the "201014007_lecture_9.pdf" file

3) Finally have to run all the functions randomly in the script. For that user have to give input to call function through    the  'Run' button

                        Hover 'Run' button -> click on 'type code to Run' -> push input -> click enter
<--------------------------------------------------------------------------------------->